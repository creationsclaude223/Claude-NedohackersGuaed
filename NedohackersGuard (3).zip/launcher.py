"""Проверяет основной файл перед запуском. Если он повреждён — возвращает из резервной копии."""
import os, sys, shutil, runpy

here = os.path.dirname(os.path.abspath(__file__))
main = os.path.join(here, "nedohackers_guard.py")
bak = os.path.join(os.environ.get("APPDATA", ""), "NedoHackersGuard", "self_backup.py")

try:
    compile(open(main, encoding="utf-8").read(), main, "exec")
except Exception:
    if os.path.exists(bak):
        shutil.copy2(bak, main)
        print("Основной файл был повреждён — восстановлен из резервной копии.")
    else:
        sys.exit("Файл повреждён, а резервной копии ещё нет. Распакуй архив заново.")

runpy.run_path(main, run_name="__main__")
