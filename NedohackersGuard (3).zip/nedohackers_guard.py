"""
Недохакеры Guard — снимок настроек системы + откат после вируса.
Только Windows. Запускай от имени администратора, чтобы работал откат hosts и HKLM.
"""
import os, sys, json, hashlib, shutil, subprocess, datetime, webbrowser, threading, time, re, html, platform
import urllib.request
import ctypes
from ctypes import wintypes
import tkinter as tk
from tkinter import messagebox, ttk

try:
    import winreg
except ImportError:
    sys.exit("Эта программа работает только в Windows.")

APP_DIR = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "NedoHackersGuard")
BASE = os.path.join(APP_DIR, "baseline.json")
FROZEN = getattr(sys, "frozen", False)          # True, когда программа собрана в .exe
SELF = sys.executable if FROZEN else os.path.abspath(__file__)
SELF_BAK = os.path.join(APP_DIR, "self_backup.exe" if FROZEN else "self_backup.py")
SELF_HASH = os.path.join(APP_DIR, "self.sha256")
HOSTS = r"C:\Windows\System32\drivers\etc\hosts"
RUN_KEYS = [
    ("HKCU", winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run"),
    ("HKLM", winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run"),
]
PROXY_PATH = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"
PROXY_VALUES = ["ProxyEnable", "ProxyServer", "AutoConfigURL"]


NOWIN = dict(creationflags=0x08000000, stdin=subprocess.DEVNULL)


def sha(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def ps(cmd):
    r = subprocess.run(["powershell", "-NoProfile", "-Command", cmd],
                       capture_output=True, text=True, errors="replace", **NOWIN)
    return (r.stdout + r.stderr).strip()


# ---------- самовосстановление ----------
VERSION = "8"


def _compiles(path):
    try:
        compile(open(path, encoding="utf-8").read(), path, "exec")
        return True
    except (SyntaxError, ValueError, OSError):
        return False


def _save_self():
    shutil.copy2(SELF, SELF_BAK)
    open(SELF_HASH, "w").write(f"{VERSION}:{sha(SELF)}")


def self_check():
    os.makedirs(APP_DIR, exist_ok=True)
    try:
        ver, good = open(SELF_HASH).read().strip().split(":", 1)
    except (OSError, ValueError):
        _save_self()
        return "Копия программы сохранена."
    if sha(SELF) == good:
        return "Целостность программы: ОК."
    if FROZEN:
        if ver != VERSION:
            _save_self()
            return "Обнаружена новая версия — обновил резервную копию."
        if os.path.exists(SELF_BAK) and sha(SELF_BAK) == good:
            dst = SELF[:-4] + ".restored.exe"
            shutil.copy2(SELF_BAK, dst)
            return f"ВНИМАНИЕ: exe изменён! Чистая копия лежит здесь: {dst}"
        return "ВНИМАНИЕ: exe изменён, а резервная копия повреждена!"
    if _compiles(SELF) and ver != VERSION:      # это законное обновление, а не порча
        _save_self()
        return "Обнаружена новая версия — обновил резервную копию."
    if os.path.exists(SELF_BAK) and sha(SELF_BAK) == good:
        shutil.copy2(SELF_BAK, SELF)
        return "Код был повреждён или изменён — я восстановил себя. Перезапусти программу."
    return "ВНИМАНИЕ: код изменён, а резервная копия повреждена!"


def ensure_admin():
    """Просит права администратора (окно UAC). Отказ не страшен — работаем с ограничениями."""
    try:
        import ctypes
        if ctypes.windll.shell32.IsUserAnAdmin() or "--no-admin" in sys.argv:
            return
        if FROZEN:
            exe, params = sys.executable, " ".join(f'"{a}"' for a in sys.argv[1:])
        else:
            exe = sys.executable
            w = exe.lower().replace("python.exe", "pythonw.exe")
            if os.path.exists(w):
                exe = w
            params = " ".join(f'"{a}"' for a in [SELF] + sys.argv[1:])
        if ctypes.windll.shell32.ShellExecuteW(None, "runas", exe, params, None, 1) > 32:
            sys.exit(0)
    except (AttributeError, OSError):
        pass


def log_crash(text):
    os.makedirs(APP_DIR, exist_ok=True)
    p = os.path.join(APP_DIR, "crash.log")
    with open(p, "a", encoding="utf-8") as f:
        f.write(f"\n=== {datetime.datetime.now()} ===\n{text}")
    return p


# ---------- снимок ----------
def read_run():
    out = {}
    for name, hive, path in RUN_KEYS:
        try:
            with winreg.OpenKey(hive, path) as k:
                i = 0
                while True:
                    try:
                        n, v, _ = winreg.EnumValue(k, i)
                        out[f"{name}|{n}"] = v
                        i += 1
                    except OSError:
                        break
        except OSError:
            pass
    return out


def read_proxy():
    out = {}
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, PROXY_PATH) as k:
            for n in PROXY_VALUES:
                try:
                    out[n] = winreg.QueryValueEx(k, n)[0]
                except OSError:
                    out[n] = None
    except OSError:
        pass
    return out


def read_tasks():
    r = subprocess.run(["schtasks", "/query", "/fo", "csv", "/nh"],
                       capture_output=True, text=True, errors="replace", **NOWIN)
    names = set()
    for line in r.stdout.splitlines():
        parts = line.split('","')
        if parts:
            names.add(parts[0].strip('"'))
    return sorted(names)


def snapshot():
    try:
        hosts = open(HOSTS, encoding="utf-8", errors="replace").read()
    except OSError:
        hosts = ""
    return {
        "time": datetime.datetime.now().isoformat(timespec="seconds"),
        "hosts": hosts,
        "run": read_run(),
        "proxy": read_proxy(),
        "tasks": read_tasks(),
        "bios": ps("(Get-CimInstance Win32_BIOS | "
                   "Select-Object -Expand SMBIOSBIOSVersion) -join ' '"),
        "languages": ps("(Get-WinUserLanguageList).LanguageTag -join ','"),
        "services": {s["Name"]: s["Path"] for s in service_list() if not is_windows_path(s["Path"])},
        "extensions": [f"{e['browser']}|{e['id']}|{e['name']}" for e in scan_extensions()],
    }


def compare(old, new):
    rep = []
    if old["hosts"] != new["hosts"]:
        rep.append("[hosts] файл изменён (так вирусы блокируют сайты антивирусов)")
    for k in new["run"]:
        if k not in old["run"]:
            rep.append(f"[автозагрузка] НОВАЯ запись: {k} -> {new['run'][k]}")
        elif old["run"][k] != new["run"][k]:
            rep.append(f"[автозагрузка] изменена запись: {k}")
    for k in old["run"]:
        if k not in new["run"]:
            rep.append(f"[автозагрузка] пропала запись: {k}")
    if old["proxy"] != new["proxy"]:
        rep.append(f"[прокси] изменено: было {old['proxy']}, стало {new['proxy']}")
    for t in sorted(set(new["tasks"]) - set(old["tasks"])):
        rep.append(f"[планировщик] новая задача: {t}")
    if old["bios"] != new["bios"]:
        rep.append(f"[BIOS] версия изменилась: {old['bios']} -> {new['bios']} (проверь!)")
    if old["languages"] != new["languages"]:
        rep.append(f"[язык] было {old['languages']}, стало {new['languages']}")
    if "services" in old:      # снимки старых версий этих полей не содержат
        for n, p in new.get("services", {}).items():
            if n not in old["services"]:
                rep.append(f"[службы] НОВАЯ служба автозапуска: {n} -> {p}")
            elif old["services"][n] != p:
                rep.append(f"[службы] у службы {n} изменился путь: {p}")
    if "extensions" in old:
        for e in sorted(set(new.get("extensions", [])) - set(old["extensions"])):
            rep.append(f"[расширения] НОВОЕ расширение: {e}")
    return rep or ["Всё чисто: отличий от снимка нет."]


# ---------- откат ----------
def restore(old):
    log = []
    cur = snapshot()
    try:
        if cur["hosts"] != old["hosts"]:
            shutil.copy2(HOSTS, os.path.join(APP_DIR, "hosts.bad"))
            open(HOSTS, "w", encoding="utf-8").write(old["hosts"])
            log.append("hosts восстановлен (испорченный сохранён как hosts.bad)")
    except OSError as e:
        log.append(f"hosts: нужны права администратора ({e})")
    for name, hive, path in RUN_KEYS:
        try:
            with winreg.OpenKey(hive, path, 0, winreg.KEY_SET_VALUE) as k:
                for key, val in cur["run"].items():
                    h, n = key.split("|", 1)
                    if h == name and old["run"].get(key) != val:
                        if key in old["run"]:
                            winreg.SetValueEx(k, n, 0, winreg.REG_SZ, old["run"][key])
                        else:
                            winreg.DeleteValue(k, n)
                            log.append(f"удалена автозагрузка {key}")
                for key, val in old["run"].items():
                    h, n = key.split("|", 1)
                    if h == name and key not in cur["run"]:
                        winreg.SetValueEx(k, n, 0, winreg.REG_SZ, val)
        except OSError as e:
            log.append(f"{name} Run: нет доступа ({e})")
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, PROXY_PATH, 0, winreg.KEY_SET_VALUE) as k:
            for n, v in old["proxy"].items():
                if v is None:
                    try:
                        winreg.DeleteValue(k, n)
                    except OSError:
                        pass
                elif isinstance(v, int):
                    winreg.SetValueEx(k, n, 0, winreg.REG_DWORD, v)
                else:
                    winreg.SetValueEx(k, n, 0, winreg.REG_SZ, v)
        log.append("прокси восстановлены")
    except OSError as e:
        log.append(f"прокси: {e}")
    log.append("Новые задачи планировщика я сам не удаляю — проверь их вручную (taskschd.msc).")
    return log


# ---------- удаление файла по имени, с хвостами ----------
def search_roots(whole_disk):
    if whole_disk:
        return [os.environ.get("SystemDrive", "C:") + "\\"]
    home = os.path.expanduser("~")
    return list(filter(None, [
        os.path.join(home, "Downloads"), os.path.join(home, "Desktop"),
        os.environ.get("TEMP", ""), os.environ.get("TMP", ""),
        os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\CurrentVersion\Start Menu\Startup"),
        os.environ.get("APPDATA", ""), os.environ.get("LOCALAPPDATA", ""),
        os.environ.get("PROGRAMDATA", ""), r"C:\Users\Public"]))


def find_files(name_part, ext, whole_disk=False, limit=300):
    name_part = (name_part or "").strip().lower()
    ext = (ext or "").strip().lower()
    if ext and not ext.startswith("."):
        ext = "." + ext
    if not name_part and not ext:
        return []
    found, seen = [], set()
    for root in search_roots(whole_disk):
        if not root or not os.path.isdir(root):
            continue
        base = root.rstrip(os.sep).count(os.sep)
        for r, dirs, files in os.walk(root):
            if whole_disk and r.count(os.sep) - base > 7:
                dirs[:] = []
            for f in files:
                lf = f.lower()
                if name_part and name_part not in lf:
                    continue
                if ext and not lf.endswith(ext):
                    continue
                p = os.path.join(r, f)
                if not is_protected(p) and p not in seen:
                    seen.add(p)
                    found.append(p)
                if len(found) >= limit:
                    return found
    return found


def kill_by_path(path):
    esc = path.replace("'", "''")
    return ps(f"Get-Process | Where-Object {{ $_.Path -eq '{esc}' }} | "
              "ForEach-Object { Stop-Process -Id $_.Id -Force }")


def remove_tails(path):
    log, low = [], path.lower()
    for name, hive, sub in RUN_KEYS:
        try:
            with winreg.OpenKey(hive, sub, 0, winreg.KEY_ALL_ACCESS) as k:
                i, names = 0, []
                while True:
                    try:
                        n, v, _ = winreg.EnumValue(k, i); i += 1
                    except OSError:
                        break
                    if low in str(v).lower():
                        names.append(n)
                for n in names:
                    winreg.DeleteValue(k, n)
                    log.append(f"удалена автозагрузка {name}\\{n}")
        except OSError:
            pass
    base = os.path.basename(path).replace("'", "''")
    svc = ps(f"Get-CimInstance Win32_Service | Where-Object {{ $_.PathName -like '*{base}*' }} | "
             "ForEach-Object { sc.exe delete $_.Name; $_.Name }")
    for s in svc.splitlines():
        if s.strip():
            log.append(f"удалена служба: {s.strip()}")
    tasks = ps(f"Get-ScheduledTask | Where-Object {{ ($_.Actions | ForEach-Object {{ $_.Execute + ' ' + "
               f"$_.Arguments }}) -like '*{base}*' }} | ForEach-Object {{ "
               "Unregister-ScheduledTask -TaskName $_.TaskName -Confirm:$false; $_.TaskName }")
    for t in tasks.splitlines():
        if t.strip():
            log.append(f"удалена задача планировщика: {t.strip()}")
    return log


def schedule_delete_on_reboot(path):
    try:
        return bool(ctypes.windll.kernel32.MoveFileExW(path, None, 4))  # MOVEFILE_DELAY_UNTIL_REBOOT
    except (AttributeError, OSError):
        return False


def delete_file_completely(path):
    if is_protected(path):
        return [f"{path}: защищённый системный путь, не трогаю."]
    log = [f"Удаляю: {path}"]
    kill_by_path(path)
    log.append("связанные процессы остановлены")
    log += remove_tails(path)
    try:
        os.remove(path)
        log.append("файл удалён полностью")
    except OSError as e:
        if schedule_delete_on_reboot(path):
            log.append(f"файл занят — будет удалён при следующей перезагрузке Windows ({e})")
        else:
            log.append(f"не удалось удалить: {e}")
    return log


# ---------- BIOS / загрузка ----------
BIOS_BASE = os.path.join(APP_DIR, "bios_baseline.json")
PROTECTED_BOOT_IDS = {"{bootmgr}", "{current}", "{default}", "{globalsettings}", "{dbgsettings}",
                      "{badmemory}", "{emssettings}", "{ramdiskoptions}", "{resumeloadersettings}",
                      "{memdiag}", "{ntldr}", "{fwbootmgr}"}


def bios_info():
    return {"version": ps("(Get-CimInstance Win32_BIOS).SMBIOSBIOSVersion -join ' '"),
            "manufacturer": ps("(Get-CimInstance Win32_BIOS).Manufacturer"),
            "release": ps("(Get-CimInstance Win32_BIOS).ReleaseDate")}


def boot_entries():
    out = ps("bcdedit /enum firmware")
    entries, cur = {}, None
    for line in out.splitlines():
        line = line.strip()
        m = re.match(r"identifier\s+(\{[^}]+\})", line, re.I)
        if m:
            cur = m.group(1)
            entries[cur] = {"id": cur, "description": ""}
            continue
        m = re.match(r"description\s+(.*)", line, re.I)
        if m and cur:
            entries[cur]["description"] = m.group(1).strip()
    return entries


def bios_snapshot():
    return {"time": datetime.datetime.now().isoformat(timespec="seconds"),
           "bios": bios_info(), "boot": boot_entries()}


def bios_compare(old, new):
    changes = []
    if old.get("bios") != new.get("bios"):
        changes.append(f"BIOS изменился: было {old.get('bios')}, стало {new.get('bios')}")
    new_entries = [e for bid, e in new.get("boot", {}).items()
                   if bid not in old.get("boot", {}) and bid not in PROTECTED_BOOT_IDS]
    return changes, new_entries


def delete_boot_entry(bid):
    if bid in PROTECTED_BOOT_IDS:
        return "защищённая запись, не трогаю"
    out = ps(f"bcdedit /delete {bid} /f")
    return out.strip() or "удалено"


# ---------- слежка за полноэкранными окнами ----------
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000


def process_path_fast(pid):
    try:
        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if not h:
            return ""
        buf = ctypes.create_unicode_buffer(1024)
        size = wintypes.DWORD(1024)
        k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size))
        k32.CloseHandle(h)
        return buf.value
    except (AttributeError, OSError):
        return ""


def is_fullscreen_foreground(exclude_path):
    """Возвращает (pid, путь) чужого окна, занявшего весь экран, или None."""
    try:
        u = ctypes.windll.user32
        hwnd = u.GetForegroundWindow()
        if not hwnd:
            return None
        rect = wintypes.RECT()
        u.GetWindowRect(hwnd, ctypes.byref(rect))
        sw, sh = u.GetSystemMetrics(0), u.GetSystemMetrics(1)
        if not (rect.left <= 0 and rect.top <= 0 and rect.right >= sw and rect.bottom >= sh):
            return None
        pid = wintypes.DWORD()
        u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        path = process_path_fast(pid.value)
        if not path or (exclude_path and os.path.abspath(path).lower() == os.path.abspath(exclude_path).lower()):
            return None
        if path.lower().endswith(("explorer.exe",)):
            return None
        return pid.value, path, hwnd
    except (AttributeError, OSError):
        return None


class ScreenWatcher:
    """Опрашивает активное окно раз в секунду. Если что-то чужое держит весь экран
    HOLD_SECONDS подряд — зовёт on_trigger(pid, path). Не трогает ничего сама."""
    HOLD_SECONDS = 6

    def __init__(self, on_trigger, exclude_path):
        self.on_trigger, self.exclude_path = on_trigger, exclude_path
        self.running = False
        self.whitelist = set()
        self._last_hwnd, self._since, self._fired_hwnd = None, 0, None

    def start(self):
        if self.running:
            return
        self.running = True
        threading.Thread(target=self._loop, daemon=True).start()

    def stop(self):
        self.running = False

    def _loop(self):
        while self.running:
            time.sleep(1)
            try:
                self._tick()
            except Exception:
                pass

    def _tick(self):
        info = is_fullscreen_foreground(self.exclude_path)
        if not info:
            self._since, self._last_hwnd = 0, None
            return
        pid, path, hwnd = info
        if path in self.whitelist:
            return
        if hwnd == self._last_hwnd:
            self._since += 1
        else:
            self._since, self._last_hwnd = 1, hwnd
        if self._since == self.HOLD_SECONDS and hwnd != self._fired_hwnd:
            self._fired_hwnd = hwnd
            self.on_trigger(pid, path)


# ---------- охота на подозрительное ----------
NET_STATE = os.path.join(APP_DIR, "net_off.json")
CFG = os.path.join(APP_DIR, "config.json")
QUAR_DIR = os.path.join(APP_DIR, "quarantine")
PROTECTED = [os.environ.get("WINDIR", r"C:\Windows").lower(), os.path.abspath(APP_DIR).lower()]
UP_CMD = "(Get-NetAdapter | Where-Object Status -eq 'Up').Name"


def is_protected(path):
    return any(path.lower().startswith(p) for p in PROTECTED)


def suspects():
    """Процессы с активным интернетом, у которых нет валидной цифровой подписи."""
    cmd = ("Get-NetTCPConnection -State Established | ForEach-Object { "
           "$p = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue; "
           "if ($p -and $p.Path) { "
           "$s = (Get-AuthenticodeSignature $p.Path).Status; "
           "if ($s -ne 'Valid') { [pscustomobject]@{Pid=$p.Id;Name=$p.Name;"
           "Path=$p.Path;Remote=$_.RemoteAddress} } } } | ConvertTo-Json")
    raw = ps(cmd)
    try:
        data = json.loads(raw) if raw else []
    except ValueError:
        return []
    if isinstance(data, dict):
        data = [data]
    seen, out = set(), []
    for d in data:
        if d["Path"] not in seen:
            seen.add(d["Path"])
            out.append(d)
    return out


MODELS = ["claude-haiku-5-5", "claude-sonnet-5-5", "claude-opus-5-5"]


def get_key():
    k = os.environ.get("ANTHROPIC_API_KEY")
    if k:
        return k
    try:
        return json.load(open(CFG, encoding="utf-8")).get("api_key") or None
    except (OSError, ValueError):
        return None


def set_key(k):
    os.makedirs(APP_DIR, exist_ok=True)
    json.dump({"api_key": k}, open(CFG, "w", encoding="utf-8"))


def ask_one(model, prompt, key):
    body = json.dumps({"model": model, "max_tokens": 200,
                       "messages": [{"role": "user", "content": prompt}]}).encode()
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages", body,
        {"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            return json.loads(r.read())["content"][0]["text"].strip(), None
    except urllib.error.HTTPError as e:
        return None, f"{model}: HTTP {e.code}" + (" (ключ не принят)" if e.code in (401, 403) else "")
    except Exception as e:
        return None, f"{model}: {e}"


def ask_claude(name, path, digest):
    """Консилиум: спрашивает несколько моделей Claude параллельно и сводит вердикты.
    Это совет, а не приговор. Отправляются только имя, путь и SHA-256."""
    key = get_key()
    if not key:
        return None
    prompt = (f"Windows-файл без цифровой подписи.\nИмя: {name}\nПуть: {path}\nSHA-256: {digest}\n"
              "Что это за файл? Начни ответ ровно с одного слова: SAFE, SUSPICIOUS или UNKNOWN, "
              "затем одна короткая фраза. Если не уверен — пиши UNKNOWN, не выдумывай.")
    results = {}

    def work(m):
        results[m] = ask_one(m, prompt, key)

    ths = [threading.Thread(target=work, args=(m,)) for m in MODELS]
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    votes, notes, errs = [], [], []
    for m in MODELS:
        text, err = results[m]
        if err:
            errs.append(err)
            continue
        mt = re.match(r"\s*(SAFE|SUSPICIOUS|UNKNOWN)", text.upper())
        votes.append(mt.group(1) if mt else "UNKNOWN")
        notes.append(f"{m.replace('claude-', '')}: {text[:110]}")
    if not votes:
        return "UNKNOWN (модели недоступны: " + "; ".join(errs) + ")"
    sus = votes.count("SUSPICIOUS")
    if sus >= 2 or (sus >= 1 and len(votes) < 3):
        verdict = "SUSPICIOUS"
    elif all(v == "SAFE" for v in votes):
        verdict = "SAFE"
    else:
        verdict = "UNKNOWN"
    return (f"{verdict} (консилиум {len(votes)} из {len(MODELS)}: {', '.join(votes)})\n   "
            + "\n   ".join(notes))


def net_off():
    names = [n for n in ps(UP_CMD).splitlines() if n.strip()]
    if names:
        json.dump(names, open(NET_STATE, "w"))   # запоминаем, чтобы включить обратно даже после сбоя
    for n in names:
        ps(f"Disable-NetAdapter -Name '{n}' -Confirm:$false")


def net_on():
    if os.path.exists(NET_STATE):
        for n in json.load(open(NET_STATE)):
            ps(f"Enable-NetAdapter -Name '{n}' -Confirm:$false")
        os.remove(NET_STATE)


def quarantine(item):
    """Отключает сеть, держит её выключенной, убивает процесс, переносит файл в карантин
    (НЕ удаляет), чистит автозагрузку, затем возвращает сеть."""
    log, stop = [], threading.Event()

    def guard():                       # не даёт включить интернет, пока идёт обезвреживание
        while not stop.is_set():
            for n in ps(UP_CMD).splitlines():
                if n.strip():
                    ps(f"Disable-NetAdapter -Name '{n.strip()}' -Confirm:$false")
            time.sleep(1)

    net_off()
    log.append("интернет отключён")
    t = threading.Thread(target=guard, daemon=True)
    t.start()
    try:
        subprocess.run(["taskkill", "/F", "/PID", str(item["Pid"])], capture_output=True, **NOWIN)
        log.append(f"процесс {item['Pid']} остановлен")
        os.makedirs(QUAR_DIR, exist_ok=True)
        dst = os.path.join(QUAR_DIR, os.path.basename(item["Path"]) + ".quar")
        try:
            shutil.move(item["Path"], dst)
            log.append(f"файл перенесён в карантин: {dst}")
        except OSError as e:
            log.append(f"файл не перенесён ({e})")
        for key, val in read_run().items():          # хвосты в автозагрузке
            if item["Path"].lower() in str(val).lower():
                h, n = key.split("|", 1)
                hive = winreg.HKEY_CURRENT_USER if h == "HKCU" else winreg.HKEY_LOCAL_MACHINE
                try:
                    with winreg.OpenKey(hive, RUN_KEYS[0][2], 0, winreg.KEY_SET_VALUE) as k:
                        winreg.DeleteValue(k, n)
                    log.append(f"удалена автозагрузка {key}")
                except OSError:
                    log.append(f"не смог удалить автозагрузку {key}")
    finally:
        stop.set()
        t.join()
        net_on()
        log.append("интернет включён обратно")
    return log


# ---------- проверка на вирусы ----------
RUN_EXT = {".exe", ".dll", ".scr", ".com", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".jar"}
SIG_EXT = {".exe", ".dll", ".scr", ".com"}
DOC_EXT = {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".jpg", ".jpeg", ".png", ".txt", ".mp3", ".mp4", ".zip", ".rar"}


def scan_dirs(deep=False):
    home = os.path.expanduser("~")
    dirs = [os.path.join(home, "Downloads"), os.path.join(home, "Desktop"),
            os.environ.get("TEMP", ""),
            os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs\Startup")]
    if deep:
        dirs += [os.path.join(home, "Documents"), os.environ.get("APPDATA", ""),
                 os.environ.get("LOCALAPPDATA", ""), os.environ.get("PROGRAMDATA", ""),
                 r"C:\Users\Public"]
    return dirs


def unsigned(paths):
    bad = []
    for i in range(0, len(paths), 25):
        lst = ",".join("'" + p.replace("'", "''") + "'" for p in paths[i:i + 25])
        out = ps(f"Get-AuthenticodeSignature -LiteralPath {lst} | "
                 "ForEach-Object { $_.Path + '|' + $_.Status }")
        for line in out.splitlines():
            if "|" in line:
                p, s = line.rsplit("|", 1)
                if s.strip() != "Valid":
                    bad.append(p)
    return bad


def heuristic_scan(say, deep=False):
    sus, cands, total = [], [], 0
    for d in scan_dirs(deep):
        if not d or not os.path.isdir(d):
            continue
        say(f"Смотрю: {d}")
        base = d.rstrip(os.sep).count(os.sep)
        for root, dirs, files in os.walk(d):
            if root.count(os.sep) - base >= 3:
                dirs[:] = []
            for f in files:
                if total >= (60000 if deep else 20000):
                    break
                total += 1
                parts = f.lower().split(".")
                ext = "." + parts[-1] if len(parts) > 1 else ""
                p = os.path.join(root, f)
                if ext in RUN_EXT and len(parts) >= 3 and "." + parts[-2] in DOC_EXT:
                    sus.append((p, "двойное расширение: маскируется под документ"))
                elif ext in SIG_EXT and len(cands) < (400 if deep else 100):
                    cands.append(p)
    cands = list(dict.fromkeys(cands))
    say(f"Файлов просмотрено: {total}. Проверяю цифровые подписи ({len(cands)} шт.)...")
    for p in unsigned(cands):
        sus.append((p, "нет валидной цифровой подписи"))
    uniq = {}
    for p, why in sus:
        uniq.setdefault(p, why)
    return list(uniq.items())


def defender_scan(say, full=False):
    say("Запускаю " + ("ПОЛНУЮ" if full else "быструю") + " проверку Microsoft Defender (" + ("может идти час и больше" if full else "несколько минут") + ")...")
    out = ps(f"Start-MpScan -ScanType {'FullScan' if full else 'QuickScan'}; 'DONE'")
    if "DONE" not in out or "rror" in out:
        return None, out[:200]
    names = ps("Get-MpThreat | ForEach-Object { $_.ThreatName }")
    return [t for t in names.splitlines() if t.strip()], ""


def quarantine_file(path):
    os.makedirs(QUAR_DIR, exist_ok=True)
    dst = os.path.join(QUAR_DIR, os.path.basename(path) + ".quar")
    try:
        shutil.move(path, dst)
    except OSError as e:
        return f"{path}: не перенесён ({e})"
    for key, val in read_run().items():
        if path.lower() in str(val).lower():
            h, n = key.split("|", 1)
            hive, sub = RUN_KEYS[0][1:] if h == "HKCU" else RUN_KEYS[1][1:]
            try:
                with winreg.OpenKey(hive, sub, 0, winreg.KEY_SET_VALUE) as k:
                    winreg.DeleteValue(k, n)
            except OSError:
                pass
    return f"{path} -> карантин"


RISKY = ("\\temp\\", "\\appdata\\", "\\downloads\\", "\\programdata\\", "\\users\\public\\")


def risky_processes():
    out = ps("Get-Process | Where-Object Path | ForEach-Object { $_.Id.ToString() + '|' + $_.Path }")
    items = []
    for line in out.splitlines():
        if "|" in line:
            pid, p = line.split("|", 1)
            if pid.strip().isdigit() and any(r in p.lower() for r in RISKY) and not is_protected(p):
                items.append({"Pid": int(pid), "Path": p.strip(), "Name": os.path.basename(p.strip())})
    bad = set(unsigned([i["Path"] for i in items]))
    return [i for i in items if i["Path"] in bad]


def odd_services():
    out = ps("Get-CimInstance Win32_Service | Where-Object { $_.StartMode -eq 'Auto' -and $_.PathName "
             "-and $_.PathName -notmatch 'Windows|Program Files' } | "
             "ForEach-Object { $_.Name + '|' + $_.PathName }")
    return [l for l in out.splitlines() if "|" in l]


# ---------- браузеры, расширения, службы ----------
ALL_URLS = {"<all_urls>", "*://*/*", "http://*/*", "https://*/*"}
SAFE_PAGES = ("google.", "bing.com", "yandex.", "ya.ru", "duckduckgo.com", "youtube.com",
              "microsoft.com", "msn.com", "about:", "chrome://", "edge://", "browser://",
              "opera:", "brave://", "newtab")


def is_windows_path(p):
    return p.lower().startswith(os.environ.get("WINDIR", r"C:\Windows").lower())


def load_json(path):
    try:
        return json.load(open(path, encoding="utf-8-sig"))
    except (OSError, ValueError):
        return None


def browser_profiles():
    local, roam = os.environ.get("LOCALAPPDATA", ""), os.environ.get("APPDATA", "")
    roots = {"Chrome": os.path.join(local, "Google", "Chrome", "User Data"),
             "Edge": os.path.join(local, "Microsoft", "Edge", "User Data"),
             "Brave": os.path.join(local, "BraveSoftware", "Brave-Browser", "User Data"),
             "Yandex": os.path.join(local, "Yandex", "YandexBrowser", "User Data"),
             "Opera": os.path.join(roam, "Opera Software", "Opera Stable")}
    for br, root in roots.items():
        if not os.path.isdir(root):
            continue
        if br == "Opera":
            yield br, root
            continue
        for d in sorted(os.listdir(root)):
            if d == "Default" or d.startswith("Profile "):
                yield br, os.path.join(root, d)


def ext_name(vdir, man):
    n = str(man.get("name", "?"))
    if n.startswith("__MSG_") and n.endswith("__"):
        key = n[6:-2].lower()
        for loc in (man.get("default_locale"), "en", "ru"):
            msgs = load_json(os.path.join(vdir, "_locales", loc or "en", "messages.json"))
            if isinstance(msgs, dict):
                for k, v in msgs.items():
                    if k.lower() == key and isinstance(v, dict):
                        return v.get("message", n)
    return n


def scan_extensions():
    out = []
    for br, prof in browser_profiles():
        ed = os.path.join(prof, "Extensions")
        if not os.path.isdir(ed):
            continue
        for eid in sorted(os.listdir(ed)):
            base = os.path.join(ed, eid)
            if not os.path.isdir(base):
                continue
            vers = sorted(d for d in os.listdir(base) if os.path.isdir(os.path.join(base, d)))
            if not vers:
                continue
            vdir = os.path.join(base, vers[-1])
            man = load_json(os.path.join(vdir, "manifest.json"))
            if not isinstance(man, dict):
                continue
            perms = {str(p).lower() for p in (man.get("permissions") or []) + (man.get("host_permissions") or [])
                     if isinstance(p, str)}
            for cs in man.get("content_scripts") or []:
                perms.update(str(m).lower() for m in (cs.get("matches") or []))
            out.append({"browser": br, "id": eid, "name": ext_name(vdir, man), "perms": perms})
    return out


def ext_risk(e):
    p = e["perms"]
    strong = p & {"nativemessaging", "debugger", "proxy"}
    extra = p & {"webrequestblocking", "cookies", "history", "clipboardread", "management", "downloads"}
    if strong:
        return "опасные разрешения: " + ", ".join(sorted(strong))
    if (p & ALL_URLS) and len(extra) >= 2:
        return "доступ ко всем сайтам + " + ", ".join(sorted(extra))
    return None


def browser_settings():
    res = []
    for br, prof in browser_profiles():
        d = load_json(os.path.join(prof, "Preferences"))
        if not isinstance(d, dict):
            continue
        urls = []
        if d.get("homepage") and d.get("homepage_is_newtabpage") is False:
            urls.append(str(d["homepage"]))
        sess = d.get("session") or {}
        if sess.get("restore_on_startup") == 4:
            urls += [str(u) for u in sess.get("startup_urls") or []]
        for u in urls:
            if not any(s in u.lower() for s in SAFE_PAGES):
                res.append((br, u))
    return res


def service_list():
    out = ps("Get-CimInstance Win32_Service | Where-Object { $_.StartMode -eq 'Auto' -and $_.PathName } | "
             "ForEach-Object { $_.Name + '|' + $_.State + '|' + $_.PathName }")
    items = []
    for line in out.splitlines():
        parts = line.split("|", 2)
        if len(parts) != 3:
            continue
        m = re.match(r'\s*"([^"]+)"|\s*(.+?\.(?:exe|sys|dll))', parts[2], re.I)
        path = (m.group(1) or m.group(2)) if m else parts[2].split(" ")[0]
        items.append({"Name": parts[0], "State": parts[1], "Path": os.path.expandvars(path.strip())})
    return items


def audit_system(say):
    """Расширения и настройки браузеров + службы автозапуска. Возвращает число находок."""
    n = 0
    exts = scan_extensions()
    say(f"Расширений в браузерах: {len(exts)}")
    for e in exts:
        why = ext_risk(e)
        if why:
            n += 1
            say(f"Проверь расширение: {e['name']} ({e['browser']}, id {e['id']})", f"   причина: {why}")
    for br, u in browser_settings():
        n += 1
        say(f"Проверь настройку: {br} открывает {u}",
            "   причина: нетипичная страница, именно её подменяют браузерные угонщики")
    svcs = [s for s in service_list() if not is_windows_path(s["Path"])]
    say(f"Служб автозапуска вне папки Windows: {len(svcs)}")
    cand = []
    for s in svcs:
        low = s["Path"].lower()
        if not os.path.exists(s["Path"]):
            n += 1
            say(f"Проверь службу: {s['Name']}", "   причина: файл службы не найден (остаток после удаления вируса?)")
        elif any(r in low for r in RISKY):
            n += 1
            say(f"Проверь службу: {s['Name']} -> {s['Path']}", "   причина: запускается из пользовательской папки")
        else:
            cand.append(s)
    cand = cand[:80]
    bad = set(unsigned([s["Path"] for s in cand]))
    for s in cand:
        if s["Path"] in bad:
            n += 1
            say(f"Проверь службу: {s['Name']} -> {s['Path']}", "   причина: нет цифровой подписи")
    return n


# ---------- отчёт ----------
def build_report_html(log, status):
    colors = {"ok": "#34d399", "bad": "#f87171", "warn": "#fbbf24", "h": "#60a5fa", "": "#e6edf3"}
    bad = sum(1 for t, _ in log if t == "bad")
    warn = sum(1 for t, _ in log if t == "warn")
    try:
        import ctypes
        admin = "да" if ctypes.windll.shell32.IsUserAnAdmin() else "нет"
    except (AttributeError, OSError):
        admin = "неизвестно"
    rows = "\n".join(
        f'<div style="color:{colors.get(t, colors[""])}{";font-weight:700" if t == "h" else ""}">'
        f'{html.escape(l) or "&nbsp;"}</div>' for t, l in log)
    when = datetime.datetime.now().strftime("%d.%m.%Y %H:%M:%S")
    info = html.escape(f"{when} | компьютер: {platform.node()} | {platform.platform()} | "
                       f"права администратора: {admin} | версия программы: {VERSION}")
    return f"""<!doctype html><html lang="ru"><head><meta charset="utf-8">
<title>Недохакеры Guard — отчёт</title></head>
<body style="margin:0;background:#0f1419;font-family:Segoe UI,Arial,sans-serif;color:#e6edf3">
<div style="max-width:960px;margin:0 auto;padding:24px">
<h1 style="margin:0 0 4px">🛡 Недохакеры Guard — отчёт</h1>
<div style="color:#8b98a5;margin-bottom:16px">{info}</div>
<div style="background:#1d2530;padding:14px 18px;border-radius:8px;font-size:20px;font-weight:700">{html.escape(status)}</div>
<div style="margin:12px 0;color:#8b98a5">Красных находок: <b style="color:#f87171">{bad}</b> · Предупреждений: <b style="color:#fbbf24">{warn}</b></div>
<div style="background:#161c24;padding:16px;border-radius:8px;font-family:Consolas,monospace;font-size:14px;white-space:pre-wrap;line-height:1.5">
{rows}
</div></div></body></html>"""


# ---------- интерфейс ----------
BG, PANEL, CARD, HOVER = "#0f1419", "#161c24", "#1d2530", "#2a3544"
ACCENT, ACCENT_H = "#3b82f6", "#2563eb"
TEXT, MUTED = "#e6edf3", "#8b98a5"
GOOD, WARN, BAD = "#34d399", "#fbbf24", "#f87171"


class Btn(tk.Label):
    def __init__(self, parent, text, cmd, accent=False):
        self._bg = ACCENT if accent else CARD
        self._hv = ACCENT_H if accent else HOVER
        super().__init__(parent, text=text, bg=self._bg, fg=TEXT, anchor="w", padx=14, pady=4,
                         font=("Segoe UI", 10, "bold" if accent else "normal"), cursor="hand2")
        self.bind("<Enter>", lambda e: self.config(bg=self._hv))
        self.bind("<Leave>", lambda e: self.config(bg=self._bg))
        self.bind("<Button-1>", lambda e: cmd())


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Недохакеры Guard")
        self.geometry("1040x760")
        self.minsize(900, 640)
        self.configure(bg=BG)
        self.busy = False
        self.log = []
        st = ttk.Style(self)
        st.theme_use("clam")
        st.configure("N.Horizontal.TProgressbar", troughcolor=PANEL, background=ACCENT,
                     bordercolor=PANEL, lightcolor=ACCENT, darkcolor=ACCENT)

        side = tk.Frame(self, bg=PANEL, width=270)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)
        tk.Label(side, text="🛡  Недохакеры Guard", bg=PANEL, fg=TEXT,
                 font=("Segoe UI", 15, "bold")).pack(anchor="w", padx=16, pady=(18, 12))
        groups = [
            ("ЗАЩИТА", [("🔍  Быстрая проверка", self.scan, True),
                        ("🧪  Глубокая проверка", self.deep_scan, True),
                        ("🧩  Браузеры и службы", self.audit, False),
                        ("🎯  Охота на угрозы", self.hunt, False),
                        ("📦  Песочница", self.sandbox, False),
                        ("🗑️  Удалить файл с хвостами", self.delete_dialog, False)]),
            ("СНИМОК И ОТКАТ", [("📸  Сделать снимок", self.make_base, False),
                                ("🧿  Запомнить BIOS", self.remember_bios, False),
                                ("✅  Проверить изменения", self.check, False),
                                ("↩️  Откатить изменения", self.rollback, False)]),
            ("WINDOWS", [("💾  Точка восстановления", self.restore_point, False),
                         ("⏪  Откатить Windows", self.open_restore, False),
                         ("🇷🇺  Вернуть русский язык", self.lang, False),
                         ("🔑  Забыл пароль", self.password, False),
                         ("❔  Что это?", self.explain, False)]),
            ("НАСТРОЙКИ", [("🤖  API-ключ Claude", self.api_key, False),
                           ("📄  Сохранить отчёт", self.save_report, False)]),
        ]
        for title, items in groups:
            tk.Label(side, text=title, bg=PANEL, fg=MUTED,
                     font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=18, pady=(12, 4))
            for text, cmd, acc in items:
                Btn(side, text, cmd, acc).pack(fill="x", padx=12, pady=2)

        main = tk.Frame(self, bg=BG)
        main.pack(side="left", fill="both", expand=True, padx=16, pady=16)
        self.banner = tk.Label(main, text="Готов к работе", bg=CARD, fg=GOOD, anchor="w",
                               padx=16, pady=14, font=("Segoe UI", 13, "bold"))
        self.banner.pack(fill="x")
        self.watcher = ScreenWatcher(lambda pid, path: self.after(0, self.on_screen_lock_detected, pid, path), SELF)
        self.watch_btn = Btn(main, "👁️  Слежка за экраном: выкл", self.toggle_watch)
        self.watch_btn.pack(fill="x", pady=(8, 0))
        self.bar = ttk.Progressbar(main, mode="indeterminate", style="N.Horizontal.TProgressbar")
        self.bar.pack(fill="x", pady=(8, 8))
        box = tk.Frame(main, bg=PANEL)
        box.pack(fill="both", expand=True)
        sb = tk.Scrollbar(box)
        sb.pack(side="right", fill="y")
        self.out = tk.Text(box, bg=PANEL, fg=TEXT, bd=0, padx=12, pady=10, wrap="word",
                           font=("Consolas", 10), state="disabled", yscrollcommand=sb.set)
        self.out.pack(fill="both", expand=True)
        sb.config(command=self.out.yview)
        for tag, color in [("ok", GOOD), ("bad", BAD), ("warn", WARN), ("h", ACCENT)]:
            self.out.tag_config(tag, foreground=color)
        self.out.tag_config("h", font=("Consolas", 10, "bold"))

        res = self_check()
        self.say(res)
        if "ВНИМАНИЕ" in res:
            self.set_status("Код программы повреждён!", BAD)
        if os.path.exists(NET_STATE):
            net_on()
            self.say("Прошлый сеанс оборвался при очистке — интернет включён обратно.")
        if not os.path.exists(BASE):
            self.say("Снимка ещё нет — нажми «Сделать снимок» на чистой системе.")
        self.say("Для проверки на вирусы запускай программу от имени администратора.")

    def report_callback_exception(self, exc, val, tb):
        import traceback
        p = log_crash("".join(traceback.format_exception(exc, val, tb)))
        self.say(f"Ошибка: {val}", f"Подробности в файле: {p}")
        self.set_status("Ошибка (см. журнал)", BAD)

    def set_status(self, text, color=GOOD):
        self.after(0, lambda: self.banner.config(text=text, fg=color))

    def say(self, *lines):
        for l in lines:
            if threading.current_thread() is threading.main_thread():
                self._say(l)
                self.update_idletasks()
            else:
                self.after(0, self._say, l)

    def _say(self, l):
        if l.startswith("---"):
            tag = "h"
        elif any(w in l for w in ("ОК", "чисто", "Ничего", "восстановлен", "ГОТОВО", "Точка создана")):
            tag = "ok"
        elif l.startswith("Найдено") or any(w in l for w in ("ВНИМАНИЕ", "НОВАЯ", "Не вышло", "подозр")):
            tag = "bad"
        elif l.startswith("Проверь"):
            tag = "warn"
        else:
            tag = None
        self.log.append((tag or "", l))
        self.out.config(state="normal")
        self.out.insert("end", l + "\n", tag)
        self.out.see("end")
        self.out.config(state="disabled")

    def scan(self):
        if self.busy:
            return
        self.busy = True
        self.bar.start(12)
        self.set_status("Идёт проверка...", WARN)
        self.say("--- Проверка на вирусы ---")
        threading.Thread(target=self._scan_worker, daemon=True).start()

    def _scan_worker(self):
        try:
            sus = heuristic_scan(self.say)
            for p, why in sus:
                self.say(f"Найдено: {p}", f"   причина: {why}")
            threats, err = defender_scan(self.say)
            if threats is None:
                self.say("Defender недоступен (включён другой антивирус или нет прав).", err)
            elif threats:
                self.say(f"Найдено угроз по базе Defender (включая историю): {len(threats)}",
                         *[f"   {t}" for t in threats])
            else:
                self.say("Defender: угроз нет.")
            total = len(sus) + len(threats or [])
            if total:
                self.set_status(f"Найдено подозрительного: {total}", BAD)
                self.say("Подозрительное — не значит вирус. Проверь файлы руками и в «Охоте на угрозы».")
            else:
                self.set_status("Всё чисто", GOOD)
                self.say("Ничего подозрительного не найдено.")
        except Exception as e:
            self.say(f"Ошибка проверки: {e}")
            self.set_status("Ошибка проверки", BAD)
        finally:
            self.after(0, self._done)

    def api_key(self):
        w = tk.Toplevel(self)
        w.title("API-ключ Claude")
        w.configure(bg=PANEL)
        w.geometry("540x270")
        w.transient(self)
        tk.Label(w, text="Свой API-ключ Anthropic", bg=PANEL, fg=TEXT,
                 font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=18, pady=(16, 4))
        tk.Label(w, text="Хранится только на этом компьютере (%APPDATA%\\NedoHackersGuard).\n"
                 "Консилиум: Haiku + Sonnet + Opus голосуют, подозрительный ли файл.",
                 bg=PANEL, fg=MUTED, justify="left").pack(anchor="w", padx=18)
        e = tk.Entry(w, show="•", bg=CARD, fg=TEXT, insertbackground=TEXT, bd=0,
                     font=("Consolas", 11))
        e.pack(fill="x", padx=18, pady=12, ipady=8)
        e.insert(0, get_key() or "")
        msg = tk.Label(w, text="", bg=PANEL, fg=MUTED, justify="left", wraplength=500)
        msg.pack(anchor="w", padx=18)

        def save():
            set_key(e.get().strip())
            msg.config(text="Сохранено.", fg=GOOD)

        def test():
            save()
            msg.config(text="Проверяю...", fg=WARN)
            w.update_idletasks()
            text, err = ask_one(MODELS[0], "Ответь одним словом: ок", e.get().strip())
            msg.config(text="Ключ работает." if text else f"Не вышло: {err}",
                       fg=GOOD if text else BAD)

        row = tk.Frame(w, bg=PANEL)
        row.pack(fill="x", padx=18, pady=12)
        Btn(row, "Сохранить", save, True).pack(side="left", padx=(0, 8))
        Btn(row, "Проверить ключ", test).pack(side="left")

    def deep_scan(self):
        if self.busy:
            return
        if not messagebox.askyesno("Глубокая проверка",
                                   "Включает ПОЛНУЮ проверку Defender: от 30 минут до нескольких "
                                   "часов. Компьютер будет работать медленнее. Запустить?"):
            return
        self.busy = True
        self.bar.start(12)
        self.set_status("Глубокая проверка...", WARN)
        self.say("--- Глубокая проверка ---")
        threading.Thread(target=self._deep_worker, daemon=True).start()

    def _deep_worker(self):
        flagged = []
        extra = 0
        try:
            self.say("Шаг 1/5: запущенные процессы из пользовательских папок без подписи...")
            for p in risky_processes():
                self.say(f"Найдено: {p['Path']} (pid {p['Pid']})")
                flagged.append(p)
            self.say("Шаг 2/5: службы, расширения и настройки браузеров...")
            extra = audit_system(self.say)
            self.say("Шаг 3/5: расширенный поиск файлов (AppData, ProgramData, Documents...)")
            for p, why in heuristic_scan(self.say, deep=True):
                self.say(f"Найдено: {p}", f"   причина: {why}")
                flagged.append({"Pid": None, "Path": p, "Name": os.path.basename(p)})
            self.say("Шаг 4/5: Microsoft Defender")
            threats, err = defender_scan(self.say, full=True)
            if threats is None:
                self.say("Defender недоступен (другой антивирус или нет прав).", err)
            elif threats:
                self.say(f"Найдено угроз по базе Defender: {len(threats)}", *[f"   {t}" for t in threats])
            else:
                self.say("Defender: угроз нет.")
            seen, uniq = set(), []
            for f in flagged:
                if f["Path"] not in seen:
                    seen.add(f["Path"])
                    uniq.append(f)
            flagged = uniq
            if flagged and get_key():
                self.say(f"Шаг 5/5: консилиум Claude по файлам (до 8 из {len(flagged)})...")
                keep = []
                for i, f in enumerate(flagged):
                    if i >= 8 or not os.path.exists(f["Path"]):
                        keep.append(f)
                        continue
                    v = ask_claude(f["Name"], f["Path"], sha(f["Path"]))
                    self.say(f"{f['Name']}: {v}")
                    if not (v and v.upper().startswith("SAFE")):
                        keep.append(f)
                flagged = keep
            elif flagged:
                self.say("Шаг 5/5 пропущен: нет API-ключа Claude.")
            total = len(flagged) + len(threats or []) + extra
            self.set_status(f"Найдено подозрительного: {total}" if total else "Всё чисто",
                            BAD if total else GOOD)
            if not total:
                self.say("Ничего подозрительного не найдено.")
            self.after(0, self._offer_quarantine, flagged)
        except Exception as e:
            self.say(f"Ошибка проверки: {e}")
            self.set_status("Ошибка проверки", BAD)
        finally:
            self.after(0, self._done)

    def _offer_quarantine(self, flagged):
        items = [f for f in flagged if os.path.exists(f["Path"]) and not is_protected(f["Path"])]
        if not items:
            return
        names = "\n".join(f["Path"] for f in items[:10]) + ("\n..." if len(items) > 10 else "")
        if messagebox.askyesno("Карантин",
                               f"Перенести в карантин ({len(items)} шт.)?\nФайлы НЕ удаляются, "
                               f"их можно вернуть.\n\n{names}"):
            for f in items:
                self.say(*(quarantine(f) if f["Pid"] else [quarantine_file(f["Path"])]))

    def audit(self):
        if self.busy:
            return
        self.busy = True
        self.bar.start(12)
        self.set_status("Проверяю браузеры и службы...", WARN)
        self.say("--- Браузеры, расширения и службы ---")
        threading.Thread(target=self._audit_worker, daemon=True).start()

    def _audit_worker(self):
        try:
            n = audit_system(self.say)
            self.set_status(f"Требует внимания: {n}" if n else "Всё чисто", WARN if n else GOOD)
            self.say("«Проверь» значит «посмотри сам»: так выглядят и вредные, и просто мощные "
                     "программы." if n else "Ничего подозрительного не найдено.")
        except Exception as e:
            self.say(f"Ошибка проверки: {e}")
            self.set_status("Ошибка проверки", BAD)
        finally:
            self.after(0, self._done)

    def save_report(self):
        if not self.log:
            self.say("Журнал пуст — нечего сохранять.")
            return
        folder = ps("[Environment]::GetFolderPath('Desktop')").strip()
        if not os.path.isdir(folder):
            folder = os.path.join(os.path.expanduser("~"), "Desktop")
        if not os.path.isdir(folder):
            folder = APP_DIR
        base = os.path.join(folder, "NedohackersGuard_report_" +
                            datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S"))
        status = self.banner.cget("text")
        try:
            with open(base + ".html", "w", encoding="utf-8") as f:
                f.write(build_report_html(self.log, status))
            with open(base + ".txt", "w", encoding="utf-8-sig", newline="") as f:
                f.write("\r\n".join([f"Недохакеры Guard — отчёт ({status})", ""] + [l for _, l in self.log]))
        except OSError as e:
            self.say(f"Не удалось сохранить отчёт: {e}")
            return
        self.say(f"Отчёт сохранён: {base}.html (и .txt рядом)")
        try:
            os.startfile(base + ".html")
        except (AttributeError, OSError):
            webbrowser.open("file:///" + (base + ".html").replace("\\", "/"))

    def _done(self):
        self.bar.stop()
        self.busy = False


    def load(self):
        if not os.path.exists(BASE):
            self.say("Сначала сделай снимок.")
            return None
        return json.load(open(BASE, encoding="utf-8"))

    def make_base(self):
        if os.path.exists(BASE) and not messagebox.askyesno(
                "Снимок", "Перезаписать старый снимок? Делай это только на чистой системе."):
            return
        self.say("Снимаю конфигурацию...")
        json.dump(snapshot(), open(BASE, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        self.say("Снимок сохранён.")

    def check(self):
        old = self.load()
        if old:
            self.say("--- Проверка ---", *compare(old, snapshot()))
        self.check_bios()

    def remember_bios(self):
        self.set_status("Запоминаю BIOS и загрузку...", WARN)
        self.say("Запоминаю конфигурацию BIOS и загрузки...")
        json.dump(bios_snapshot(), open(BIOS_BASE, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        self.say("Готово. Дальше при «Проверить изменения» я буду сверяться с этим снимком.")
        self.set_status("Готов к работе")

    def check_bios(self):
        try:
            base = json.load(open(BIOS_BASE, encoding="utf-8"))
        except (OSError, ValueError):
            return
        self.say("--- BIOS и загрузка ---")
        cur = bios_snapshot()
        changes, new_entries = bios_compare(base, cur)
        if changes:
            self.say(*changes, "Это саму прошивку не трогает: поменять её можно только в меню "
                     "BIOS/UEFI при включении компьютера.")
        for e in new_entries:
            if messagebox.askyesno("Новая конфигурация в загрузке",
                                   f"Добавленная новая конфигурация:\n{e['description']}\n({e['id']})"
                                   "\n\nУдалить?"):
                self.say(delete_boot_entry(e["id"]))
            else:
                self.say(f"Оставил: {e['description']}")
        if not changes and not new_entries:
            self.say("Без изменений.")

    def rollback(self):
        old = self.load()
        if old and messagebox.askyesno("Откат", "Вернуть hosts, автозагрузку и прокси из снимка?"):
            self.say("--- Откат ---", *restore(old))

    def lang(self):
        self.say(ps("Set-WinUserLanguageList -LanguageList ru-RU,en-US -Force; 'Русский язык добавлен.'"),
                 "Если интерфейс не сменился — перезайди в систему.")

    def password(self):
        self.say("Старый пароль вернуть нельзя: Windows хранит только хеш.",
                 "Открываю официальное восстановление аккаунта Microsoft.",
                 "Для локального аккаунта: вход с другого админа или диск восстановления.")
        webbrowser.open("https://account.live.com/password/reset")

    def hunt(self):
        self.say("--- Охота: неподписанные программы с доступом в интернет ---")
        found = suspects()
        if not found:
            self.say("Ничего подозрительного не найдено.")
            return
        for s in found:
            if is_protected(s["Path"]):
                self.say(f"{s['Name']}: системная папка, пропускаю.")
                continue
            digest = sha(s["Path"]) if os.path.exists(s["Path"]) else "?"
            verdict = ask_claude(s["Name"], s["Path"], digest)
            self.say(f"{s['Name']} (pid {s['Pid']}) -> {s['Remote']}",
                     f"  путь: {s['Path']}",
                     f"  Claude: {verdict or 'нет API-ключа (кнопка «API-ключ Claude»)'}")
            if verdict and verdict.upper().startswith("SAFE"):
                continue
            if messagebox.askyesno(
                    "Обезвредить?",
                    f"{s['Name']}\n{s['Path']}\n\nОтключить интернет, остановить процесс и "
                    "перенести файл в карантин? Интернет включится сам после очистки."):
                self.say(*quarantine(s))

    def restore_point(self):
        self.say("Создаю точку восстановления Windows (минута-две)...")
        out = ps("Enable-ComputerRestore -Drive \"$env:SystemDrive\\\"; "
                 "Checkpoint-Computer -Description 'NedoHackers Guard' "
                 "-RestorePointType MODIFY_SETTINGS; 'ГОТОВО'")
        if "ГОТОВО" in out and "rror" not in out and "ошибк" not in out.lower():
            self.say("Точка создана. Если что-то сломается — жми «Откатить Windows».")
        else:
            self.say("Не вышло. Нужны права администратора и включённая защита системы.",
                     "Windows по умолчанию даёт не больше одной точки за 24 часа.",
                     f"Ответ системы: {out[:300]}")

    def open_restore(self):
        self.say("Открываю мастер отката Windows. Выбери точку ДО заражения.")
        subprocess.Popen(["rstrui.exe"])

    def explain(self):
        self.say(
            "--- Что делают эти кнопки ---",
            "«Создать точку восстановления» запоминает системные файлы Windows, реестр,",
            "драйверы и установленные программы на текущий момент.",
            "«Откатить Windows» возвращает всё это к выбранной точке.",
            "",
            "Работает, только если точку создали ДО заражения. Если нажать после — ты",
            "сохранишь уже заражённое состояние.",
            "",
            "Чего откат НЕ делает:",
            " - не трогает личные файлы (документы, фото, загрузки): их не вернёт и не удалит;",
            " - не гарантирует удаление вируса: если он лежит в личных папках, он останется;",
            " - не спасёт от шифровальщиков: многие стирают точки восстановления;",
            " - не лечит BIOS и прошивки;",
            " - не возвращает пароли и аккаунты в интернете.",
            "",
            "Лучшая схема: точка на чистой системе + «Сделать снимок» + регулярные",
            "бэкапы важных файлов на внешний диск.")

    def delete_dialog(self):
        w = tk.Toplevel(self)
        w.title("Удалить файл с хвостами")
        w.configure(bg=PANEL)
        w.geometry("620x460")
        w.transient(self)
        tk.Label(w, text="Удалить файл по имени и типу", bg=PANEL, fg=TEXT,
                 font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=16, pady=(14, 2))
        tk.Label(w, text="Удаление полное: без корзины, вместе с автозагрузкой, службами и\n"
                 "задачами планировщика, которые на файл ссылаются. Отменить нельзя.",
                 bg=PANEL, fg=MUTED, justify="left").pack(anchor="w", padx=16)
        row = tk.Frame(w, bg=PANEL); row.pack(fill="x", padx=16, pady=10)
        tk.Label(row, text="Имя файла (часть имени):", bg=PANEL, fg=TEXT).grid(row=0, column=0, sticky="w")
        name_e = tk.Entry(row, bg=CARD, fg=TEXT, insertbackground=TEXT, bd=0, font=("Consolas", 10))
        name_e.grid(row=0, column=1, sticky="ew", padx=8, ipady=5)
        tk.Label(row, text="Тип файла (.exe, .dll...):", bg=PANEL, fg=TEXT).grid(row=1, column=0, sticky="w", pady=(8, 0))
        ext_e = tk.Entry(row, bg=CARD, fg=TEXT, insertbackground=TEXT, bd=0, font=("Consolas", 10))
        ext_e.grid(row=1, column=1, sticky="ew", padx=8, pady=(8, 0), ipady=5)
        row.columnconfigure(1, weight=1)
        whole = tk.BooleanVar(value=False)
        tk.Checkbutton(w, text="искать по всему диску C: (медленно)", variable=whole, bg=PANEL, fg=MUTED,
                       selectcolor=CARD, activebackground=PANEL, activeforeground=TEXT).pack(anchor="w", padx=16)
        box = tk.Frame(w, bg=PANEL); box.pack(fill="both", expand=True, padx=16, pady=10)
        sb = tk.Scrollbar(box); sb.pack(side="right", fill="y")
        lb = tk.Listbox(box, bg=CARD, fg=TEXT, selectmode="extended", font=("Consolas", 9),
                        yscrollcommand=sb.set)
        lb.pack(fill="both", expand=True)
        sb.config(command=lb.yview)
        status = tk.Label(w, text="", bg=PANEL, fg=MUTED)
        status.pack(anchor="w", padx=16)

        def find():
            lb.delete(0, "end")
            status.config(text="Ищу...", fg=WARN); w.update_idletasks()
            found = find_files(name_e.get(), ext_e.get(), whole.get())
            for p in found:
                lb.insert("end", p)
            status.config(text=f"Найдено: {len(found)}" + (" (показаны первые)" if len(found) >= 300 else ""),
                         fg=TEXT if found else MUTED)

        def do_delete():
            sel = [lb.get(i) for i in lb.curselection()]
            if not sel:
                status.config(text="Ничего не выбрано.", fg=WARN)
                return
            if not messagebox.askyesno("Подтверждение",
                                       f"Удалить безвозвратно {len(sel)} файл(ов)?\n\n" + "\n".join(sel[:10])):
                return
            self.say("--- Удаление файлов ---")
            for p in sel:
                self.say(*delete_file_completely(p))
            w.destroy()

        br = tk.Frame(w, bg=PANEL); br.pack(fill="x", padx=16, pady=(0, 14))
        Btn(br, "Найти", find).pack(side="left", padx=(0, 8))
        Btn(br, "Удалить выбранное", do_delete, True).pack(side="left")

    def toggle_watch(self):
        if self.watcher.running:
            self.watcher.stop()
            self.watch_btn.config(text="👁️  Слежка за экраном: выкл", bg=CARD)
            self.say("Слежка за экраном выключена.")
        else:
            self.watcher.start()
            self.watch_btn.config(text="👁️  Слежка за экраном: вкл", bg=ACCENT)
            self.say("Слежка включена: если что-то займёт весь экран дольше 6 секунд подряд и "
                     "не даст переключиться, появится окно с вопросом. На полноэкранных играх и "
                     "фильмах возможны ложные срабатывания — тогда жми «Это не вирус».")

    def on_screen_lock_detected(self, pid, path):
        w = tk.Toplevel(self)
        w.title("Недохакеры Guard")
        w.configure(bg=PANEL)
        w.attributes("-topmost", True)
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        w.geometry(f"540x260+{(sw - 540) // 2}+{(sh - 260) // 2}")
        w.grab_set()
        w.lift(); w.focus_force()
        tk.Label(w, text="⚠️  Это приложение — вирус?", bg=PANEL, fg=WARN,
                 font=("Segoe UI", 15, "bold")).pack(pady=(20, 6))
        tk.Label(w, text=f"Весь экран занимает:\n{path}\n\nОно не даёт переключиться "
                 f"дольше {ScreenWatcher.HOLD_SECONDS} секунд.",
                 bg=PANEL, fg=TEXT, justify="center", wraplength=480).pack(pady=4)
        row = tk.Frame(w, bg=PANEL); row.pack(pady=18)

        def act_close():
            subprocess.run(["taskkill", "/PID", str(pid)], capture_output=True, **NOWIN)
            self.say(f"Процесс {pid} ({path}) закрыт.")
            w.destroy()

        def act_delete():
            subprocess.run(["taskkill", "/F", "/PID", str(pid)], capture_output=True, **NOWIN)
            self.say("--- Удаление подозрительного окна ---", *delete_file_completely(path))
            w.destroy()

        def act_ignore():
            self.watcher.whitelist.add(path)
            self.say(f"Отмечено как не вирус: {path}")
            w.destroy()

        Btn(row, "Закрыть", act_close, True).pack(side="left", padx=6)
        Btn(row, "Удалить", act_delete).pack(side="left", padx=6)
        Btn(row, "Это не вирус — не закрывать", act_ignore).pack(side="left", padx=6)

    def sandbox(self):
        exe = r"C:\Windows\System32\WindowsSandbox.exe"
        if os.path.exists(exe):
            subprocess.Popen([exe])
        else:
            self.say("Windows Sandbox не включена (нужна Pro/Enterprise).",
                     "Включить: Компоненты Windows -> Windows Sandbox, потом перезагрузка.")


if __name__ == "__main__":
    import traceback
    try:
        ensure_admin()
        App().mainloop()
    except Exception:
        path = log_crash(traceback.format_exc())
        try:
            messagebox.showerror("Недохакеры Guard", f"Программа упала.\nПодробности: {path}")
        except Exception:
            pass
