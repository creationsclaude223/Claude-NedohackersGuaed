@echo off
cd /d "%~dp0"
set PYCMD=
where py >nul 2>nul && set PYCMD=py -3
if not defined PYCMD where python >nul 2>nul && set PYCMD=python
if not defined PYCMD (
  echo Python not found. Install it from https://www.python.org/downloads/
  echo Tick "Add python.exe to PATH" in the installer.
  pause
  exit /b 1
)
%PYCMD% launcher.py
if errorlevel 1 pause
